# LinkedIn post (DRAFT, not published)

Review and edit this yourself before posting. Nothing here has been published.

## Post

315 minutes. That's how long a receipt took from truck arrival to stock available in my practice dataset. Unloading was 43 of them.

I work in warehouse operations, and the first guess for slow receiving is usually the dock. So I built a small project to test that guess.

I simulated 4,000 inbound receipts (simulated data, not from any employer) and split each one into nine steps, five of them waiting time between steps.

Results from the simulated data:
- 46% of the total time was waiting, not work
- 72% happened after unloading finished
- QC-to-GRN wait and GRN processing took about 41% together

I scored each step on delay share, variability and SLA breaches, then ran a what-if. The model indicates that bringing just those two steps to their SLA could take about 68 minutes off the average receipt, or about 34 if only half the excess is removed. The SLAs are my own assumptions.

I built these patterns into the data generator myself, so the results only demonstrate the method. I made it in Excel and I'm building the Power BI version next.

For anyone in inbound: where do you usually find the longest wait, at the dock or in the paperwork?

P.S. The workbook and files are in the first comment.

#SupplyChain #WarehouseOperations

## First comment

GitHub link: (paste your repo URL here after you upload)

## Best time to post

Tuesday to Thursday, 7:30 to 9:00 AM.

## Featured section

- **Title:** Dock-to-Stock Bottleneck Analysis (simulated data)
- **Description:** Excel and Power BI project that finds which inbound step delays stock availability the most.

## Caption for the dashboard screenshot

Bottleneck Score by step, simulated data. QC-to-GRN wait and GRN processing score highest.

## Check before you post

1. "I work in warehouse operations, and the first guess for slow receiving is usually the dock." Change it if it doesn't match what you have seen.
2. "I'm building the Power BI version next" is only true while you are building it. Update it once the dashboard is done, or remove it.
3. Keep the "simulated data" lines.
4. The 68 and 34 minute figures come from the Decision_Model sheet and depend on my SLA assumptions. Keep the wording "the model indicates".
5. If you want to mention your skill level, write it in your own words.

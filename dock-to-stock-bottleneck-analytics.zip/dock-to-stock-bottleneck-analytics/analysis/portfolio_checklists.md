# Portfolio checklists

## 1. Dashboard screenshots checklist

Save as PNG in `screenshots/`. Add a plain "Simulated data" note on page 1 of the report so it shows in every screenshot.

- [ ] `01_overview.png`: KPI cards (Receipts, Avg / Median / P90 dock-to-stock, Open GRNs) with Warehouse, Shift and Vendor slicers
- [ ] `02_bottleneck_score.png`: bar chart of Bottleneck Score by segment, plus the table with Priority
- [ ] `03_process_timeline.png`: average minutes per segment end to end
- [ ] `04_heatmap.png`: segment x shift matrix with colour scale
- [ ] `05_vendor_analysis.png`: vendor total time and short / damaged %
- [ ] `06_warehouse_shift.png`: warehouse x shift view
- [ ] `07_grn_ageing.png`: age buckets and open GRN list
- [ ] `08_dock_utilisation.png`: arrivals and gate wait by hour, utilisation by dock
- [ ] `09_root_cause.png`: primary delay stage x logged cause
- [ ] `10_decision_model.png`: minutes saved per segment (from Excel `Decision_Model` or a Power BI page)
- [ ] Check that no screenshot shows a real company name, real vendor name or your file path
- [ ] Check the Bottleneck Score in Power BI matches Excel (QC-to-GRN Wait about 83.8)
- [ ] Add the 2 or 3 best screenshots to the README with `![Overview](screenshots/01_overview.png)`

## 2. GitHub upload checklist

- [ ] Re-read `README.md`. Fix the "Why I picked this one" line so it matches your real experience
- [ ] Confirm "simulated data" appears at the top of the README, in `findings.md` and in the workbook's README sheet
- [ ] Confirm there is no confidential or employer data anywhere in the folder
- [ ] Open the Excel file once, click Enable Editing, and check that no cell shows an error
- [ ] Add the `.pbix` to `powerbi/` (optional; large files are fine under 100 MB)
- [ ] Add screenshots to `screenshots/`
- [ ] Create a **Public** repo named `dock-to-stock-bottleneck-analytics`
- [ ] Upload the folder contents (keep the subfolders), then **Commit changes**
- [ ] Add the description and topics: `supply-chain`, `warehouse-operations`, `excel`, `power-bi`, `dax`, `power-query`, `data-analysis`, `inbound-logistics`
- [ ] Open the repo page: README displays, images load, the CSV opens
- [ ] Paste the repo link into `linkedin/linkedin_post.md` (first comment) and your LinkedIn Featured section

## 3. Portfolio / resume project description

**Short (resume line):**

Dock-to-Stock Bottleneck Analysis (simulated data) | Excel, Power Query, DAX, Power BI, Python
- Built a 4,000-receipt simulated inbound dataset covering truck arrival to putaway across three warehouses and 12 vendors, and split each receipt into nine waiting and processing segments.
- Created a weighted Bottleneck Score (delay share, variability, SLA breaches) and a what-if model; the analysis identified QC-to-GRN wait and GRN processing as the highest-priority segments.
- Drafted a seven-rule SOP for the inbound release process and published the project with documentation on GitHub.

**Longer (portfolio / LinkedIn Featured):**

I work in warehouse operations, so I built this project around a question I recognise from the floor: when stock arrives at the dock but is not available in the system for hours, where does the time go? I simulated 4,000 inbound receipts, measured nine segments from truck arrival to putaway, and scored each one with a Bottleneck Score. In the simulated data the biggest delay sat after unloading, in the wait before GRN and in GRN processing itself. A what-if model indicates which fix could save the most minutes. The data is synthetic and the SLA targets are my own assumptions, so the results show the method rather than real warehouse performance.

## 4. Be ready to explain (interview prep)

You should be able to answer these without notes. If you can't yet, study that part before you share the project.

1. Why is the data simulated, and what did you build into the generator?
2. What is the difference between waiting time and processing time here?
3. How is the Bottleneck Score calculated, and why those three parts?
4. Why does P90 divided by median matter more than the average?
5. What does the Decision_Model assume, and why is the "half of the excess" setting more cautious?
6. What would you need from a real warehouse to repeat this on real data?
7. What would change the ranking if the SLA targets were different?
